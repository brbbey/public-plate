# FiveEngine-OzelPlaka
Donate Araçlara Sqlden Ayar yapmadan Oyun içinde hızlı bir şekilde plaka değiştirebilirsiniz 
- discord.gg/fiven
- Scripte Güncelleme İle Gelenler Özellikler 
- Aynı Plakayı Yapamama Özelliği
- 0.01 Resmon'dan 0.00 Resmondan Düşürüldü
- Aktif Olarak Güncelleme Alıcağı İçin Version Sürüm Kontrolü Eklendi
