baTu = {}

baTu.Komutnedir = 'plaka'

baTu.MenuHeader = 'baTu Özel Plaka Sistemi'
baTu.InputdaYazicakMesaj = 'Plakası Nedir'
baTu.OnayMesaji = 'Onayla'
baTu.minimumplaka = '1'
baTu.maxplaka = '8'

--WEBHOOK
baTu.Vebhook = 'WEBHOOK_YAPIŞTIR'
baTu.MesajBilgisi = 'PLAKA SİSTEMİ'
baTu.BotAdi = 'baTu'
